let votosData = [];
let votosPorRegion = {};
let votosGenerales = {};
let estadisticasPorRegion = {};
let estadisticasGenerales = {
  total: 0,
  anomaliasReales: 0,
  anomaliasDetectadas: 0,
  falsosPositivos: 0,
  falsosNegativos: 0,
  precision: 0,
  recall: 0
};
let barChartInstance = null;

// Leer ambos CSV y unir los datos
function cargarCSV(callback) {
  let archivos = ['votos_simulados_region1.csv', 'votos_simulados_region2.csv'];
  let cargados = 0;
  let datos = [];
  archivos.forEach(archivo => {
    Papa.parse(archivo, {
      header: true,
      download: true,
      complete: function(results) {
        datos = datos.concat(results.data.map(row => ({
          ...row,
          anomalo_real: row.anomalo_real !== undefined ? row.anomalo_real : "0"
        })));
        cargados++;
        if (cargados === archivos.length) {
          votosData = datos;
          callback();
        }
      }
    });
  });
}

// Procesa los votos y estadísticas
function procesarVotos() {
  votosPorRegion = {};
  votosGenerales = {};
  estadisticasPorRegion = {};
  let total = 0, anomaliasReales = 0, anomaliasDetectadas = 0, falsosPositivos = 0, falsosNegativos = 0;

  votosData.forEach(row => {
    if (!row.region || !row.candidato) return;
    // Normaliza el nombre de la región
    let region = row.region.trim().toUpperCase();

    // Inicializar estructuras
    if (!votosPorRegion[region]) votosPorRegion[region] = {};
    if (!estadisticasPorRegion[region]) estadisticasPorRegion[region] = {
      total: 0, anomaliasReales: 0, anomaliasDetectadas: 0, falsosPositivos: 0, falsosNegativos: 0
    };

    // Votos generales
    votosGenerales[row.candidato] = (votosGenerales[row.candidato] || 0) + 1;
    votosPorRegion[region][row.candidato] = (votosPorRegion[region][row.candidato] || 0) + 1;

    // Estadísticas generales
    total++;
    if (row.anomalo === "1") anomaliasDetectadas++;
    if (row.anomalo === "1" && row.anomalo_real === "1") anomaliasReales++;
    if (row.anomalo === "1" && row.anomalo_real !== "1") falsosPositivos++;
    if (row.anomalo !== "1" && row.anomalo_real === "1") falsosNegativos++;

    // Estadísticas por región
    estadisticasPorRegion[region].total++;
    if (row.anomalo === "1") estadisticasPorRegion[region].anomaliasDetectadas++;
    if (row.anomalo === "1" && row.anomalo_real === "1") estadisticasPorRegion[region].anomaliasReales++;
    if (row.anomalo === "1" && row.anomalo_real !== "1") estadisticasPorRegion[region].falsosPositivos++;
    if (row.anomalo !== "1" && row.anomalo_real === "1") estadisticasPorRegion[region].falsosNegativos++;
  });

  // Calcular precisión y recall generales
  estadisticasGenerales.total = total;
  estadisticasGenerales.anomaliasReales = anomaliasReales;
  estadisticasGenerales.anomaliasDetectadas = anomaliasDetectadas;
  estadisticasGenerales.falsosPositivos = falsosPositivos;
  estadisticasGenerales.falsosNegativos = falsosNegativos;
  estadisticasGenerales.precision = anomaliasDetectadas ? ((anomaliasReales / anomaliasDetectadas) * 100).toFixed(2) : "0.00";
  estadisticasGenerales.recall = anomaliasReales ? ((anomaliasReales / (anomaliasReales + falsosNegativos)) * 100).toFixed(2) : "0.00";

  // Por región
  for (let region in estadisticasPorRegion) {
    let est = estadisticasPorRegion[region];
    est.precision = est.anomaliasDetectadas ? ((est.anomaliasReales / est.anomaliasDetectadas) * 100).toFixed(2) : "0.00";
    est.recall = est.anomaliasReales ? ((est.anomaliasReales / (est.anomaliasReales + est.falsosNegativos)) * 100).toFixed(2) : "0.00";
  }
}

// Muestra el gráfico y las estadísticas
function mostrarGrafico(region = null) {
  let data, titulo, est, ganador = '';
  if (region) region = region.trim().toUpperCase();
  if (region && votosPorRegion[region]) {
    let regionData = votosPorRegion[region];
    let candidatos = Object.keys(regionData);
    let votos = Object.values(regionData);
    // Determinar ganador
    let maxVotos = Math.max(...votos);
    let idxGanador = votos.indexOf(maxVotos);
    ganador = candidatos[idxGanador];
    titulo = `Votos por candidato en ${region}`;
    est = estadisticasPorRegion[region];
    data = {
      labels: candidatos,
      datasets: [{
        label: 'Votos',
        data: votos,
        backgroundColor: '#497ca8'
      }]
    };
  } else {
    let candidatos = Object.keys(votosGenerales);
    let votos = Object.values(votosGenerales);
    let maxVotos = Math.max(...votos);
    let idxGanador = votos.indexOf(maxVotos);
    ganador = candidatos[idxGanador];
    titulo = "Votos generales por candidato";
    est = estadisticasGenerales;
    data = {
      labels: candidatos,
      datasets: [{
        label: 'Votos',
        data: votos,
        backgroundColor: '#497ca8'
      }]
    };
  }

  // Destruir gráfico anterior si existe
  if (barChartInstance) barChartInstance.destroy();

  // Crear nuevo gráfico
  const ctx = document.getElementById('barChart').getContext('2d');
  barChartInstance = new Chart(ctx, {
    type: 'bar',
    data: data,
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: titulo,
          font: { size: 20 }
        },
        legend: { display: false }
      },
      scales: {
        x: { title: { display: true, text: 'Candidato' } },
        y: { title: { display: true, text: 'Votos' }, beginAtZero: true }
      }
    }
  });

  // Mostrar estadísticas y ganador
  document.getElementById('stats-footer').innerHTML = `
    <div class="stats-footer">
      <div><b>Total votos procesados:</b> ${est.total}</div>
      <div><b>Anomalías reales:</b> ${est.anomaliasReales}</div>
      <div><b>Anomalías detectadas:</b> ${est.anomaliasDetectadas}</div>
      <div><b>Falsos positivos:</b> ${est.falsosPositivos}</div>
      <div><b>Falsos negativos:</b> ${est.falsosNegativos}</div>
      <div><b>Precisión:</b> ${est.precision}%</div>
      <div><b>Recall:</b> ${est.recall}%</div>
      <div style="grid-column: 1 / -1; margin-top: 10px; font-size:1.1em;">
        <b style="color:#2a7d2e;">Candidato ganador: ${ganador}</b>
      </div>
    </div>
  `;
}

// Inicializa el mapa y los eventos
function inicializarMapa() {
  var map = L.map('map').setView([-9.19, -75.015], 5);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

  $.getJSON('departamentos_perú.geojson', function(geojson) {
    L.geoJSON(geojson, {
      style: {
        color: "#3388ff",
        weight: 1,
        fillOpacity: 0.1
      },
      onEachFeature: function(feature, layer) {
        // Centroide aproximado
        var latlng;
        if (feature.geometry.type === "Polygon") {
          var coords = feature.geometry.coordinates[0];
          var lat = 0, lng = 0;
          for (var i = 0; i < coords.length; i++) {
            lng += coords[i][0];
            lat += coords[i][1];
          }
          lng /= coords.length;
          lat /= coords.length;
          latlng = [lat, lng];
        } else if (feature.geometry.type === "MultiPolygon") {
          var coords = feature.geometry.coordinates[0][0];
          var lat = 0, lng = 0;
          for (var i = 0; i < coords.length; i++) {
            lng += coords[i][0];
            lat += coords[i][1];
          }
          lng /= coords.length;
          lat /= coords.length;
          latlng = [lat, lng];
        }

        // Marcador en el centroide
        var marker = L.marker(latlng)
          .addTo(map)
          .bindPopup(feature.properties.NOMBDEP);

        marker.on("click", function() {
          document.getElementById("selected-department").innerText = "Departamento seleccionado: " + feature.properties.NOMBDEP;
          mostrarGrafico(feature.properties.NOMBDEP);
        });

        marker.on("popupclose", function() {
          document.getElementById("selected-department").innerText = "Ningún departamento seleccionado";
          mostrarGrafico();
        });
      }
    }).addTo(map);
  });
}

// Cargar y procesar los CSV al inicio
$(document).ready(function() {
  cargarCSV(function() {
    procesarVotos();
    inicializarMapa();
    mostrarGrafico(); // General al inicio
  });
// Mostrar datos generales al hacer clic en el botón
$('#btn-general').on('click', function() {
  document.getElementById("selected-department").innerText = "Ningún departamento seleccionado";
  mostrarGrafico();
  $(this).hide();
});
});